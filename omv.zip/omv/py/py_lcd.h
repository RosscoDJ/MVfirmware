/*
 * This file is part of the OpenMV project.
 * Copyright (c) 2013/2014 Ibrahim Abdelkader <i.abdalkader@gmail.com>
 * This work is licensed under the MIT license, see the file LICENSE for details.
 *
 * LCD Python module.
 *
 */
#ifndef __PY_LCD_H__
#define __PY_LCD_H__
void py_lcd_init0();
#endif // __PY_LCD_H__
